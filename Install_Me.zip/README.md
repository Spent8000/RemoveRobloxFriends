# UnaddRobloxFriends
An application that removes friends on ROBLOX


Thank you for installing my program!

Run RobloxFriendPurge.exe to remove your unwnated friends.

-> Replace ExampleUsername with your username.  *CASE SENSITIVE*
-> Replace ExamplePassword with your password.  *CASE SENSITIVE*
-> Replace ExampleFriend# with each of your friends' usernames that you would like to keep.  *CASE SENSITIVE*
-> Press 'PURGE' to clear your friends list.

A minimized chrome window will open showing progress.
If you have 2FA on, you will need to open this window and enter the code it gives.

ALL INFO IS STORED LOCALLY ON YOUR MACHINE!

If all friends are not removed, run again.

The source code is on GitHub.