# UnaddRobloxFriends
Application that unadds friends on ROBLOX in mass


Thank you for installing my program!

To use the program, edit the file 'EditMe.json' with your Notepad, or other text editor.



Replace ExampleUsername with your username.                     *CASE SENSITIVE*
Replace ExamplePassword with your password.                     *CASE SENSITIVE*
Replace ExampleFriendUsername# to each of your friends' names.  *CASE SENSITIVE*

Save the file.

Run 'UnaddRobloxFriends.exe'.

If all friends are not removed, run again.