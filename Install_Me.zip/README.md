# UnaddRobloxFriends
An application that removes friends on ROBLOX


Thank you for installing my program!

To use the program, edit the file 'EditMe.json' with your Notepad or other text editor.

-> Replace ExampleUsername with your username.  *CASE SENSITIVE*
-> Replace ExamplePassword with your password.  *CASE SENSITIVE*
-> Replace ExampleFriendUsername# with each of your friends' names that you would like to keep.  *CASE SENSITIVE*

Save and close the file.

Run 'UnaddRobloxFriends.exe'.

If all friends are not removed, run again.

The source code is on GitHub for those skeptical.